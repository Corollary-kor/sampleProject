

#Azure devOps
[wiki link](/Azure-Devops-기능-사용)
#AWS 아키텍처 구축
[wiki link](/AWS-아키텍처-구축)

[구축된 사이트](https://test.d2nb3i6ozv8hyt.amplifyapp.com)

성, 이름을 입력하면 입력된 값을 출력해준다.

pipeline 상태 확인
[![Build status](https://dev.azure.com/Cloudmate-Product/project.Dongseok/_apis/build/status/project.lambdaDeployed)](https://dev.azure.com/Cloudmate-Product/project.Dongseok/_build/latest?definitionId=37)

----
#진행상황
[진행상황](/진행상황)

