[[_TOC_]]

#개요
 간단한 웹 애플리케이션을 통해 "hello world"를 렌더링 하여 정적웹사이트를 구축한 후
사용자가 입력하는 사용자 지정 텍스트를 표시하도록 웹앱에 기능을 추가해 본다.

#학습내용
- 웹 앱 만들기
- 서버리스 백엔드에 웹 앱 연결
- API와 데이터베이스를 사용하여 웹 앱에 상호 작용 기능 추가
# 아키텍처와 사용할 서비스
![image.png](/.attachments/image-3e21fe74-3a9d-4a76-8180-1ca6983c9885.png)
- AWS Amplify
- Amazon API Gateway
- AWS Lambda
- Amazon DynamoDB
#순서
- 웹 앱 만들기: AWS Amplify 콘솔을 사용하여 웹 애플리케이션을 위한 정적 리소스를 배포합니다.
- 서버리스 함수 작성: AWS Lambda를 사용하여 서버리스 함수를 작성합니다.
- 웹 앱에 서버리스 함수 연결: API Gateway를 사용하여 서버리스 함수를 배포합니다.
- 데이터 테이블 생성: Amazon DynamoDB 테이블에 데이터를 유지합니다.
- 웹 앱에 상호 작용 기능 추가: API를 호출하도록 웹 앱을 수정합니다.
#링크
[링크](https://aws.amazon.com/ko/getting-started/hands-on/build-web-app-s3-lambda-api-gateway-dynamodb/module-one/?e=gs2020&p=build-a-web-app-intro)
