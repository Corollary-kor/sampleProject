
[[_TOC_]]

# 개요
Lambda 함수 핸들러는 이벤트를 처리하는 함수 코드의 메서드입니다. 함수가 호출되면 Lambda에서 핸들러 메서드를 실행합니다. 핸들러가 존재하거나 응답을 반환할 때, 또 다른 이벤트를 처리하기 위해 사용할 수 있게 됩니다.


# 일반적인 구문
```
def handler_name(event, context): 
    ...
    return some_value
```


# 작동방식
Lambda가 함수 핸들러를 호출할 때 Lambda 런타임은 함수 핸들러에 두 개의 인수를 전달합니다.

1. 첫 번째 인수는 이벤트 객체입니다. 이벤트는 Lambda 함수가 처리할 데이터가 포함된 JSON 형식 문서입니다. Lambda 런타임은 이벤트를 객체로 변환한 후 함수 코드에 전달합니다. 이 객체는 일반적으로 Python dict 유형입니다. 또한 list, str, int, float 또는 NoneType 유형이 될 수 있습니다.
이벤트 객체에는 호출 서비스의 정보가 포함됩니다. 함수를 호출할 때, 이벤트의 구조와 내용을 결정합니다. AWS 서비스는 함수를 호출할 때 이벤트 구조를 정의합니다. AWS 서비스의 이벤트에 대한 자세한 내용은 다른 서비스와 함께 AWS Lambda 사용 단원을 참조하십시오.
1. 두 번째 인수는 컨텍스트 객체입니다. 컨텍스트 객체는 런타임에 Lambda에 의해 함수로 전달됩니다. 이 객체는 호출, 함수 및 런타임 환경에 관한 정보를 제공하는 메서드 및 속성들을 제공합니다.

# 값 반환
선택적으로, 핸들러는 값을 반환할 수 있습니다. 반환된 값은 호출 유형 및 다른 서비스와 함께 AWS Lambda 사용에 따라 달라집니다. 예:

- 동기식 호출 같은 RequestResponse 호출 유형을 사용하는 경우에는 AWS Lambda가 Python 함수 호출의 결과를 클라이언트에 반환하여 Lambda 함수를 호출합니다(호출 요청에 대한 HTTP 응답이 JSON에 직렬화). 예를 들어 AWS Lambda 콘솔은 RequestResponse 호출 유형을 사용하기 때문에 콘솔에서 함수를 호출할 때 콘솔에 반환 값이 표시됩니다.
- 핸들러가 json.dumps로 직렬화가 불가능한 객체를 반환하는 경우 런타임에서 오류를 반환하게 됩니다.
- return 문이 포함되지 않은 Python 함수가 묵시적으로 하는 것처럼 핸들러가 None을 반환하는 경우, 런타임은 null을 반환하게 됩니다.
- Event를 비동기식 호출 호출 유형으로 사용하는 경우에는 해당 값이 폐기됩니다.


# Reference

[설명서](https://docs.aws.amazon.com/ko_kr/lambda/latest/dg/python-handler.html#naming)

[AWS Lambda 컨텍스트객체](https://docs.aws.amazon.com/ko_kr/lambda/latest/dg/python-context.html)


