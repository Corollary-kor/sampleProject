[[_TOC_]]
# 개요
Amplify 에 html올리는 방법이 로컬에서, S3에서, URL로 하는 방식이 있는데
로컬은 손으로 직접올려야하는데 접근방법을 어떻게 할지모르겠고
URL은 Azure devops REPOS에서 URL 추출을 어떻게 해야할지도 모르겟고 amplify자체에 접근하여 첨부도 못하여 못했다.
그래서 마지막 방법인 S3를 이용하기로 했다.
pipeline을 통해 S3에 업로드 한뒤, S3를 lambda를 이용하여 트리거 발생시켜 amplify에 파일을 올리는 방식을 택했다.

::: mermaid
 graph LR;
 A[S3 Pipeline] --> B[Amplify에 S3 trigger lambda 함수 생성]; 

:::

# S3 Pipeline

![image.png](/.attachments/image-40fccde3-728e-4c7e-b237-bd3469f0ffce.png)

전에 만든 pipeline에서 add task에 Amazon S3 Upload를 클릭

![image.png](/.attachments/image-30d27f58-b59c-42f5-91a5-40c4cf968bdc.png)

AWS Credentails는 전에 만들어 놓았던걸 선택하고
Region은 S3 생성했던 것을 선택, bucket name은 생성했던 S3 이름을 적어 넣는다.
Source Folder는 올릴파일이 있는 폴더를 선택(파일은 안되는것같다.)
filename Patterns 에는 파일명을 입력하면 끝(폴더내 모든파일을 올리려면 기본값으로 주어진 **을 입력하면된다.)
입력후 save하면 된다.

![image.png](/.attachments/image-18635302-02e6-4f11-937f-cc22dd35ea99.png)
S3에 잘올라와 있는것을 확인

# Lambda 함수 trigger
## 함수생성
함수 생성후 아래 코드를 입력

```
const appId = ENTER YOUR APP ID;
const branchName = ENTER YOUR BRANCH NAME;

const aws = require("aws-sdk");
const amplify = new aws.Amplify();

exports.handler = async function(event, context, callback) {
    const Bucket = event.Records[0].s3.bucket.name;
    const objectKey = event.Records[0].s3.object.key;
    await amplify.startDeployment({
        appId,
        branchName,
        sourceUrl: `s3://${Bucket}/${objectKey}`
    }).promise();
}
```
amplify URL을 보면
https://[branchname].[appId].amplifyapp.com
이런식으로 되어 있다.
appid는 amplify url에서 appId 부분을, branchnam은 url에서 branchname 을 적으면된다.
여기서 그냥 적으면 안되고 ""를 써줘야한다.

## 권한 생성

![image.png](/.attachments/image-cdb31f22-ef1a-45c4-9742-6a8b1164d331.png)

lambda에서 구성 - 권한에 들어간뒤 역할이름을 클릭

![image.png](/.attachments/image-8d9e068d-9909-4062-9fd6-d14537ba4f0e.png)

그러면 iam이 열리는데 여기서 정책연결 클릭

![image.png](/.attachments/image-2623ad35-1339-41e0-a53a-d930e1bad6e9.png)

s3fullAccess를 검색하여 선택후 정책 연결

![image.png](/.attachments/image-00df29c4-45ed-42e1-a7d1-d15ea3a37d6b.png)

그 다음 옆에 인라인 정책 추가를 클릭

![image.png](/.attachments/image-53906d50-66ed-4a35-a2be-cc3af2ed5eb6.png)

서비스는 amplify를 검색하여 선택하고 작업탭에서는 수동작업 밑에 있는 모든 Amplify를 체크하자

![image.png](/.attachments/image-2e09f1f2-2c2a-433b-ac75-cb88111e8fe2.png)

그 다음 리소스인데 모든 리소스를 선택 후 정책 검토를 클릭

![image.png](/.attachments/image-c4b1fbf4-9bbe-4003-b3e7-b69fcc8f646f.png)
여기서 이름 적고 정책생성하면 된다.

![image.png](/.attachments/image-da8e4680-17a9-4bed-b261-301be726cef8.png)
다시 lambda 함수에 가보면 구성- 정책탭에 리소스 요약에 보면 Amplify와 S3가 추가 되어 있는것을 볼수 있다.

## lambda에 S3 trigger 생성

![image.png](/.attachments/image-7443ce9c-959c-46aa-b520-f0c98c7ee370.png)
lambda 함수 첫화면 위쪽에 +트리거 추가 를 클릭

![image.png](/.attachments/image-a8dd76f8-e469-4339-9095-38c556a83a1a.png)

![image.png](/.attachments/image-124bc646-bd93-4fd8-870c-eedb0b059857.png)

트리거 선택 S3로 하고 버킷이름을 적고 추가하면 끝이다.


# Reference
https://aws.amazon.com/ko/blogs/mobile/deploy-files-s3-dropbox-amplify-console/