[[_TOC_]]

# 개요
어떤 규모에서든 개발자가 API를 손쉽게 생성, 게시, 유지 관리, 모니터링 및 보안 유지할 수 있도록 하는 완전관리형 서비스.
한마디로 API 관리 서비스 인듯하다.

# API 유형
- RESTful API
HTTP API를 사용하여 서버리스 워크로드 및 HTTP 벡엔드에 최적화된 RESTful API를 구축합니다. HTTP API는 API 프록시 기능만 필요한 API를 구축할 때 가장 적합합니다. API가 API 프록시 기능과 API 관리 기능을 요구하는 경우, API Gateway는 REST API도 제공합니다.
- WEBSOCKET API
WebSocket API를 사용하여 채팅 앱 및 스트리밍 대시보드와 같은 실시간 양방향 통신 애플리케이션을 구축합니다. API Gateway는 백엔드 서비스와 클라이언트 간의 메시지 전송을 처리하기 위해 지속적인 연결을 유지합니다.

# API Gateway 작동방식
![image.png](/.attachments/image-cccea40a-0315-44c5-9f7f-0ecf1d0d5a8e.png)

그림에서 보는것과 같이 엔드포인트에서 통신이 가능하도록 해주는것이 API Gateway 이다.


# 특징
- 동일한 API의 여러 버전을 동시에 실행하면 새로운 버전을 빠르게 반복, 테스트 및 릴리스할 수 있습니다
- Amazon CloudFront를 사용하는 엣지 로케이션의 글로벌 네트워크를 활용하여 최종 사용자에게 API 요청 및 응답에 대해 가장 짧은 지연 시간을 제공(어떤 규모에서도 뛰어난 성능)
- API 요청 요금은 최상위 티어에서 요청 백만 개당 0.90 USD 정도로 저렴
- Amazon CloudWatch를 사용하여 서비스에 대한 호출을 시각적으로 모니터링할 수 있는 API 게이트웨이 대시보드에서 성능 지표와 API 호출, 데이터 지연 시간 및 오류 발생률에 대한 정보를 모니터링
- AWS Identity and Access Management(IAM)와 Amazon Cognito를 사용하여 API에 대한 액세스 권한을 부여, 사용자 지정 권한 부여 요구 사항을 지원하기 위해 AWS Lambda에서 Lambda 권한 부여자를 실행



