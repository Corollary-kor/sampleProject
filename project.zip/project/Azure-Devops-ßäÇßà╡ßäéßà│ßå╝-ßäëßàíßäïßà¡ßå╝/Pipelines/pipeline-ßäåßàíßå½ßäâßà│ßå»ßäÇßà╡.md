![image.png](/.attachments/image-1cea7cd9-c256-453a-8c98-1d1f00dd7fec.png)


![image.png](/.attachments/image-1cccf71e-ad39-4e61-aa4d-c4adb1b703cd.png)


![image.png](/.attachments/image-61727e09-877d-407d-a43f-8fcd9abef964.png)


![image.png](/.attachments/image-405752cb-70bd-4d68-89d9-b3d1e6315c82.png)


![image.png](/.attachments/image-45003388-0ecf-458c-a5bf-ef45d2153e01.png)

![image.png](/.attachments/image-dff1ff4a-58cf-4a26-bb84-b25809b6a5da.png)


![image.png](/.attachments/image-74468786-7a96-4eda-8e6a-3cde90bf6a74.png)