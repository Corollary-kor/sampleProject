코드올리려면

requirements.txt
test_anyname.py

이 repos에 있어야 한다.

test_anyname.py 에는 잘몰라서

`def test_mock():
  assert True`
를 저장했다.