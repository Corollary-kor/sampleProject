AWS Toolkit for Microsoft Azure DevOps

https://docs.aws.amazon.com/ko_kr/vsts/latest/userguide/getting-started.html
AWS Toolkit for Microsoft Azure DevOps

![image.png](/.attachments/image-00a0c598-523e-49fe-93e4-4029b7807b64.png)

![image.png](/.attachments/image-91e2b1b1-98b0-4fad-83d5-278312b8d6f7.png)

![image.png](/.attachments/image-18f32f9d-1978-42aa-bacc-a328df3f3562.png)


SLN파일이 있어야 생성이 된다.

그리고 sln파일내용에 아래를 적으면 된다.

```
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 16
VisualStudioVersion = 16.0.28701.123
MinimumVisualStudioVersion = 10.0.40219.1
```



