대시보드설명서
https://docs.microsoft.com/ko-kr/azure/devops/report/dashboards/dashboards?view=azure-devops


위젯 카탈로그
https://docs.microsoft.com/ko-kr/azure/devops/report/dashboards/widget-catalog?view=azure-devops


#번다운

![이미지](https://upload.wikimedia.org/wikipedia/commons/8/8e/SampleBurndownChart.svg)
번 다운 차트(burn down chart)는 남아있는 일 대비 시간을 그래픽적으로 표현한 것이다. 
백로그(backlog, 뛰어난 성과)는 보통 수직축에 위치하며 시간은 수평축에 위치한다. 
즉, 뛰어난 성과의 런 차트이다. 
모든 일이 완성될 시점을 예측하는데 유용하다. 
Scrum 등의 애자일 소프트웨어 개발 방법론에 종종 사용된다. 
그러나 번 다운 차트는 시간에 따라 측정 가능한 진행상황을 포함하여 모든 프로젝트에 적용이 가능하다.