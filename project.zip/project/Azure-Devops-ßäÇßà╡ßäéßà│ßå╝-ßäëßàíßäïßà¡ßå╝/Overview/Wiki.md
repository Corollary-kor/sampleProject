위키 설명 페이지
https://docs.microsoft.com/ko-kr/azure/devops/project/wiki/about-readme-wiki?view=azure-devops

위키페이지에 작업할당
![create-embed-wit-from-wiki.gif](/.attachments/create-embed-wit-from-wiki-15278ed4-42d1-4508-aaa7-9140569894a5.gif)

단축키
페이지를 선택 하 고 ctrl + 위쪽 화살표 또는 CTRL + 아래쪽 화살표 를 눌러 페이지 순서를 변경 