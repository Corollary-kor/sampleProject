[[_TOC_]]

위에 나오게하려면 
![image.png](/.attachments/image-638f0d9e-f821-4894-a04f-698c0e7e254f.png)
하면됨.


#헤더
![image.png](/.attachments/image-808470fd-b690-4762-8a45-cfff6132b2ca.png)

----
# This is a H1 header
## This is a H2 header
### This is a H3 header
#### This is a H4 header
##### This is a H5 header

<br>
</br>

#빈공간 줄바꿈 하기
![image.png](/.attachments/image-ea2cd6e7-ace8-432b-8fc8-f956f2841e81.png)

----
위에 문법을 넣으면 된다.

<br>
</br>

#인용
![image.png](/.attachments/image-03072122-7105-43dd-a955-aa2b00731095.png)

> Single line quote
>> Nested quote
>> multiple line
>> quote

<br>
</br>

#수평선 규칙

![image.png](/.attachments/image-5acb357c-cd3b-4bc2-b600-7f189eb5a5d8.png)

above

----
below
<br>
</br>
#강조(굵게, 기울임꼴, 취소선)
![image.png](/.attachments/image-4b80cf90-471b-4dda-af99-c85c4900c875.png)

----
Use _emphasis_ in comments to express **strong** opinions and point out ~~corrections~~  
**_Bold, italicized text_**  
**~~Bold, strike-through text~~**
<br>
</br>
#코드 강죠표시
![image.png](/.attachments/image-d42fac16-2e2d-4ffc-9733-73194a329690.png)

----
```
sudo npm install vsoagent-installer -g  
```
<br>
</br>

#순서가 지정된 목록

![image.png](/.attachments/image-0f3a2ae5-d83a-4a29-bd26-2a1ac032327b.png)

----

1. First item.
1. Second item.
1. Third item.

#글머리 기호목록
![image.png](/.attachments/image-1a49539a-4d60-489a-9acf-557cfe5cbf14.png)
- Item 1
- Item 2
- Item 3

#중첩된 목록
![image.png](/.attachments/image-7cf3a240-ce0f-419a-8aad-93fd0a3d68b2.png)
1. First item.
   - Item 1
   - Item 2
   - Item 3
1. Second item.
   - Nested item 1
   - Nested item 2
   - Nested item 3
<br>
</br>
#링크

Wiki에 대해 지원 되는 링크:
![image.png](/.attachments/image-70865f52-dfdd-48af-b750-9be7bd9170d9.png)

예시:
[위키페이지로](/Azure-Devops-기능-사용/Overview/Wiki)
[Azure DevOps홈페이지로](https://dev.azure.com/Cloudmate-Product)
<br>
</br>
#이미지추가
![image.png](/.attachments/image-9458a772-632c-48fc-8beb-9d1bf4625c0c.png)

----
![Illustration to use for new users](https://azurecomcdn.azureedge.net/cvt-779fa2985e70b1ef1c34d319b505f7b4417add09948df4c5b81db2a9bad966e5/images/page/services/devops/hero-images/index-hero.jpg)


























