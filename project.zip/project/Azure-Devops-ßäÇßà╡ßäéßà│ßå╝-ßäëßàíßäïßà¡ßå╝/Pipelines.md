[[_TOC_]]

# 개요
Azure Pipelines 코드 프로젝트를 자동으로 빌드하고 테스트하여 다른 사용자가 사용할 수 있도록 합니다. 모든 언어 또는 프로젝트 형식에 작동합니다. Azure Pipelines는 코드를 지속적이고 일관되게 테스트 및 빌드하여 모든 대상에 제공하기 위해 CI(지속적인 통합)와 CD(지속적인 업데이트)를 결합합니다.

# 기능
- 모든 언어 또는 플랫폼에서 작동
- 여러 유형의 대상에 동시에 배포
- Azure 배포와 통합
- Windows, Linux 또는 Mac 머신에서 빌드
- GitHub 통합
- 오픈 소스 프로젝트에서 작동합니다.




# [파이프라인 만들기](/Azure-Devops-기능-사용/Pipelines/pipeline-만들기)

# 파이프라인 복제, 내보내기, 가져오기

파이프라인에서 파이프라인 선택
![image.png](/.attachments/image-983e315d-d5e2-4cef-b16a-8b3200d7a075.png)

여기서 edit을 누르면 yaml 파일이 나온다.
이것을 다른 pipeline에 복사 붙여넣기 하면 복제가 됨.


