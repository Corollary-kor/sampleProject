[[_TOC_]]

# 개요
포트폴리오 계획을 사용하면 여러 프로젝트에 걸쳐 모든 에픽의 상태를 보고할 수 있습니다. 또한 간단한 드래그 앤 드롭 동작으로 시작 날짜, 종료 날짜 및 기간을 변경할 수도 있습니다.
아직 베타라 많은 기능이 있지는 않았다.

# 기능
- 에픽과 피처의 기간을 변경할수 있다.
- 진행과정을 완료수와 effort를 롤업형식으로 볼수 있다.
- 다른 프로젝트를 추가하여 한번에 볼수 있다.

# 하는법
![image.png](/.attachments/image-9566fec3-c26d-44b7-acbc-c53d3362111b.png)

첫화면 오른쪽에 new plan 클릭.

![image.png](/.attachments/image-3a0e21b7-b5ce-4c7d-a445-b80c0d1cb023.png)
이름과 설명을 적고 create


![image.png](/.attachments/image-d6b21991-51d3-46e3-bb40-4938677737ce.png)

projects에서 프로젝트 선택하고 에픽과 피처를 선택하고 add 하면된다.
(epic과 feature는 한개씩만 선택이 가능하다. epic은 추가할수 있으나 feature는 에픽당 한개뿐이라 에픽 개수만큼만 추가할수 있다.)
다른프로젝트 또한 추가하여 볼수가 있다.


![image.png](/.attachments/image-5b1e758b-36f2-4cdd-a75a-fe5ae077ced1.png)

... 부분을 클릭하여 날짜를 수정할수 있고, 의존성을 확인할수 있다.

