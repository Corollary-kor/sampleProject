[[_TOC_]]

#개요
Kanban 보드에서 작업 항목을 카드로 추가, 업데이트 및 검토하여 다른 사용자와 협업하는 도구


#주요기능
- Kanban 메서드 구현
  - Kanban 보드 보기
  - 팀의 작업 방식을 지원 하기 위해 간판 보드에 표시 되는 열을 사용자 지정 합니다.
  - 진행 중인 작업을 제한 하는 WIP 제한 설정
  - 끌어서 놓기를 통해 작업 상태를 업데이트 합니다.
  - 누적 흐름 차트 보기
  - 라이브 업데이트를 설정 하거나 해제
- 사용자 스토리, 제품 백로그 항목 또는 요구 사항을 정의하여 팀이 담당하는 작업 정의
- 진행 상태를 모니터링하고 열에 끌어서 놓아 작업 항목의 상태를 업데이트합니다.
- 백로그 항목에 세부 정보 및 예상 비용 추가
- 백로그 항목에 대한 작업 또는 자식 항목을 빠르게 정의
- 인라인 테스트 추가, 실행 및 업데이트
<br/>
</br>
#사용방법 예시
![사용방법](https://docs.microsoft.com/ko-kr/azure/devops/boards/boards/media/8_7_02.gif?view=azure-devops)
이런식으로 항목을 드래그하여 항목의 상태를 바꿀수 있다.
<br/>
</br>
# Boards에서 Analytics, Dashboards의 위젯으로 표현

## Cumulative Flow Diagram
![Cumulative Flow Diagram](https://docs.microsoft.com/ko-kr/azure/devops/report/dashboards/media/cfd/analytics-cfd-azure-devops.png?view=azure-devops)

위와 같은 Cumulative Flow Diagram을 Boards에서 Analystic 탭에서 확인할 수 있고 
Dashboards에서 위젯으로 추가하여 볼수가 있다.

나의 경우는 상태가 closed, Active만 있어서 해당 상태의 누적만을 볼수 있다.

##Velocity

![image.png](/.attachments/image-661c089a-3e0e-4163-8e97-2e14bbc4d45f.png)

지정한 iteration을 단위로 속도를 측정하는데 나같은 경우는 1iteration만 있어서 속도가 측정이 0이 되어있다. 
iteration과 항목의 상태에 따라 작업속도를 측정할수 있다.


# 항목에 목록 추가

![이미지](https://docs.microsoft.com/ko-kr/azure/devops/boards/boards/media/add-tasks-menu-options-vs-ts.png?view=azure-devops)

![이미지](https://docs.microsoft.com/ko-kr/azure/devops/boards/boards/media/kanban-board-task-checklists-added.png?view=azure-devops)

항목에 따라 메뉴가 달라지지만 하위 작업을 추가할수 있고 추가한뒤 체크박스로 완료할수도 있다.
<br/>
</br>

#Feature Timeline과 Epic Roadmap
![image.png](/.attachments/image-dd0151d6-87c7-4474-bc14-5a399bfa3fe8.png)

![image.png](/.attachments/image-a2d2a9ee-4c61-4819-a0e5-95683c4b746e.png)

feature Timeline은 epic과 feature를 이용하여 iteration 설정대로 feature 별 기간을 보여준다.

Epic Raod 는 Epic 별로 보여주는 feature tiemline이라고 보면된다.

feature Timeline 쪽이 더 상세하게 보여주고 Epic Road맵쪽이 간략하게 보여주고 있다.



<br/>
</br>


#Reference
[Kanban Board](https://www.ciokorea.com/news/132799)

