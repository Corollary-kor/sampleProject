[[_TOC_]]

# 개요
내가 정한 조건에 맞는 항목을 보거나 업데이트등을 할수 있는 것 

쿼리를 사용하여 지정한 필드 기준에 따라 버그, 사용자 스토리 또는 기타 작업 항목을 나열합니다. 그런 다음 팀과 함께 이러한 목록을 검토하거나, 작업을 심사하거나, 작업 항목을 대량 업데이트할 수 있습니다. 관리되는 쿼리 외에도 의미 체계 검색 도구는 탐색할 가치가 있거나 겹칠수 있는 다른 기능을 제공합니다.


# 기능
- 웹 포털을 사용하여 작업 항목 대량 업데이트(backlog와 마찬가지로 ctrl 키로 여러개 선택후 수정하면된다.)
- 작업 항목 심사 및 업데이트
- 작업 항목의 계층 구조 검토
- 팀 구성원과 작업 항목 목록 공유

# 사용방법
![image.png](/.attachments/image-30220e6b-3e2f-4b76-bf71-09e2068b7736.png)
첫화면은 Favorites으로 선택이 되어 있어서 아무것도 없다. All을 선택한다.

![image.png](/.attachments/image-c129c369-36c2-46cc-a1e1-975740018318.png)
처음엔 assigned to me 밖에 없을 것이다(Follow를 했다면 Followed work items가 있을것)
그럼 Assigned to me를 선택한다.


![image.png](/.attachments/image-a36fe2fa-fff2-48eb-93ca-89a321ff88ea.png)
들어가서 첫화면에 보면 workitem이 나열되어 있다.

왼쪽위에 보면 Result, Editor, Chart 가 있다. 
result는 쿼리 결과, editor는 쿼리 입력하는곳, chart는 쿼리 결과를 chart형식으로 출력해준다.
지금은 쿼리가 없어서 run query해도 같다.
New를 선택하면 work item을 생성할수도 있다.


![image.png](/.attachments/image-da7ad5eb-d896-4cb9-ad0b-4777e9e6c60a.png)

editor에 들어가면 위 와같은 화면이 있다.
field에 조건을 넣고 operator에 연산자, value에는 값을 넣고 Run query를 클릭하면
아래에 결과 값이 출력된다.
 그리고 Save query를 하면 해당 쿼리가 저장된다.

>Type of query에서 Tree of workitem을 선택하면 트리구조로 결과 값이 출력된다.

>Query across project(checkbox): 지금은 프로젝트가 하나라서 못하지만 여러개일경우 여러 프로젝트들을 쿼리할수 있다.

![image.png](/.attachments/image-f1bca5e3-7abd-4eac-8c67-728b3c67b60c.png)

![image.png](/.attachments/image-ad1e914a-ab1a-4e25-865a-0ea0bd9da2d3.png)
이런식으로 저장되어 원하는 항목을 분류해서 한눈에 볼수 있다.

##Chart
![image.png](/.attachments/image-61b99239-8fe8-47e6-9e96-8d610fec4559.png)
차트의 경우 Tree구조면 출력이 안되므로 flat으로 저장후 차트를 선택하면 출력이 된다.
