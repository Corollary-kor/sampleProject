Boards에 입력할 카테고리같은것을 추가 수정 삭제 등을 할수 있다.
권한은 administrator를 가지고 있어야 가능하다.
![image.png](/.attachments/image-6929fc40-7554-4083-adc6-eab17e226c96.png)

왼쪽아래에 organization settings 클릭

![image.png](/.attachments/image-9e3b4d54-1bfa-4fb7-b840-cfe1d4854849.png)

Boards에서 Process 탭 누르고 바꾸고 싶은 process를 선택하고 수정하고 싶은 boards의 항목을 누른다.

![image.png](/.attachments/image-00627b24-68e6-49bb-bcaf-a6bab1db53e8.png)

이런식으로 해당 항목에 대한 입력할수 있는 설정값을 수정해 줄수 있다. 