[[_TOC_]]

# 개요
스프린트에는 iteration을 기반으로 필터링된 백로그와, 마찬가지로 필터링된 보드, 그리고 할당된 작업의 기간을 볼수 있는 Capacity가 있다. 이를 통해 스크럼 사례를 구현하는 기능이다.
이를 통해 반복경로를 사용하여 특정 기간 및 주기 내에서 수행할 작업을 계획 할 수 있다.

# 기능
스프린트 예약 및 계획
작업보드 업데이트
스프린트 번다운 모니터링

# 방법
![image.png](/.attachments/image-c24a31ea-99a2-479a-8855-5e2638031c98.png)

Taskboard나 blacklog에 오른쪽을 보면 스프린트라고 하는것이나온다.
밑에 New Sprint를 클릭하여 추가하면 새 스프린트가 생기고 그곳에 task나 백로그를 드래그하여 갖다 놓으면 작업에 대한 기간이 할당된다.
해당 기간에 대한 작업이나 유저스토리가 아이콘으로 표시가 된다.

# Capacity
![image.png](/.attachments/image-a9edfcd4-cd3b-410c-a853-eeccb1214aa1.png)
해당 기간에 가능한 팀이 보유한 총근무 시간을 적어서 알수 있다.

![image.png](/.attachments/image-b624f455-d86a-443e-bcb7-ac9c614bdad6.png)
위에서 오른쪽에 톱니바퀴인 view option에서 planning이 아닌 work details를 선택하면 
capacity chart가 나온다. 이를 토대로 시간이 많은사람에게 작업을 할당 할수 있다.

이시간이 어떤 기준으로 설정되는지 헷갈린다. 
아마 내 작업량과 capacity에서 설정한 값을 기준으로 되는것같다.

# Analytics
![image.png](/.attachments/image-cb07c976-63e0-4c69-aee2-a46f9eab759d.png)
스프린트에 대한 내용을 스프린트 번다운으로 확인할 수 있다.


