[[_TOC_]]

# 개요
Delivery Plans는  여러 스프린트의 여러 팀이 개발 중인 기능을 파악할 수 있습니다. 포트폴리오 관리자는 Delivery Plans을 통해 팀이 제공하려는 스토리 또는 기능의 일정을 검토할 수 있습니다. 배달 계획은 선택된 팀의 스프린트(반복 경로)별 예약된 작업 항목을 **달력 보기**에서 보여 줍니다.

# 기능
- 최대 15개의 팀 백로그 보기, 다양한 프로젝트의 백로그 및 팀 혼합 포함
- 사용자 지정 포트폴리오 백로그 및 대규모 사용자 스토리 추가
- 여러 반복에 걸쳐 있는 작업 항목 보기
- 끌어서 놓기 테두리를 통해 시작 날짜 및 대상 날짜 다시 설정
- 계획에서 팀에 백로그 항목 추가
- 기능, 대규모 사용자 스토리, 기타 포트폴리오 항목의 롤업 진행률 보기
- 작업 항목 간에 존재하는 의존성 보기
- 관련자가 계획을 볼 수 있음

> 액세스 및 수정 권한이 있어야 이기능을 활용할 수 있다.


# 항목 설명

![image.png](/.attachments/image-8634c62f-8234-4a7a-822e-2f24df38cd29.png)

# 하는법
![image.png](/.attachments/image-bd20e356-dacc-41ca-b999-740308445035.png)
첫 화면이라 new plan을 눌러 생성

![image.png](/.attachments/image-dfb981f3-9508-437d-9c42-cfcefbb3c92c.png)
이름과 설명을 넣고
아래에 보고 싶은 프로젝트를 추가하면된다.(참여할수 있는 권한이 있어야 추가할수 있다.
그리고 criteria field가 있는데 나타내고 싶은 것의 기준(ex. work item의 feature라던가)을 넣으면 된다.

![image.png](/.attachments/image-f93e350e-9647-4595-a30d-97a08831f99b.png)

그럼 iteration에 따라 기준이 나열되는것을 볼수 있다.

여기서 sprint처럼 드래그해서 해당 iteration에 배치해도 되고 추가할수도 있다.


![image.png](/.attachments/image-a5e8c484-b3dd-4a05-ba22-c3dfc1351c62.png)
설정 - field 항목에서 show child rollup data를 선택하면

![image.png](/.attachments/image-81d2c1d5-2c6e-4ffa-9465-607eff6e8546.png)
위와 같이 child의 롤업을 볼수가 있다.