[[_TOC_]]
#사용법
1. Azure devOps에 저장소 작성(git init) 또는 복제(git clone)
1. 파일의 작성, 편집
1. 파일의 생성/변경/삭제를 git인덱스에 추가(git add)
1. 변경 결과를 로컬 저장소에 커밋(git commit)
1. 로컬 저장소를 푸쉬해 원격저장소에 반영(git push)



#사용
repos에 들어가면 아래와 같은화면이 나옴

![image.png](/.attachments/image-705ced8e-5e3c-406b-a4c1-7b9193145cc8.png)

clone에서 vscode를 선택하면 알아서 설정이된다.
Generate Git Credntials를 클릭하여 비밀번호를 vscode에서 요구하는대로 입력해줬다.

![image.png](/.attachments/image-6d864c64-5ff2-4e94-89e6-1777226b011e.png)

![image.png](/.attachments/image-63cfeb2a-00f7-472f-9e50-492f07864863.png)



::: mermaid
 graph LR;
 A[git init] --> B[git add example.py]; 
B --> C[git commit -m descriptive message];
C --> D[git origin branch];

:::



<br/>
</br>

#결과
Azure DevOps repos 로 확인해본결과 파일이 잘올라왔다.
![image.png](/.attachments/image-cfcbfd47-ee85-417c-bb7c-5089deffaded.png)
