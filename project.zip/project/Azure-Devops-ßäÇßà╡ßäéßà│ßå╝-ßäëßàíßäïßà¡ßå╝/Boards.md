
[[_TOC_]]

#Boards 란?
Scrum 및 Kanban, 사용자 지정 가능한 대시보드 및 통합 보고에 대한 기본 지원을 비롯한 다양한 기능을 제공
사용자 스토리, 백로그 항목, 작업, 기능 및 프로젝트와 관련 된 버그 추적을 빠르고 쉽게 시작할 수 있습니다.

#주요항목 설명
 - Work items: 사용자에게 할당된 작업 항목을 신속하게 찾으려면 이를 사용합니다. 팔로우 하는 작업 항목 등 다른 기준에 따라 작업 항목을 피벗 하거나 필터링합니다.
<span style="color:red;font-weight:bold">**(작업항목 생성 및 검색)**</span>

- Boards: 보드는 작업 항목을 카드로 표시하고 끌어서 놓기를 통해 빠른 상태 업데이트를 지원합니다. 이 기능은 실제 화이트보드의 스티커 메모와 비슷합니다.이를 사용 하여 간판 사례를 구현 하고 팀에 대한 작업 흐름을 시각화합니다.
<span style="color:red;font-weight:bold">**(작업 상태 업데이트, 흐름 시각화)**</span>

- Backlogs: 백로그는 작업 항목을 목록으로 표시합니다. 제품 백로그는 팀과 추적하고 공유하는데 필요한 모든 정보의 리포지토리 및 프로젝트 계획을 나타냅니다. 포트폴리오 백로그를 사용하면 백로그를 그룹화하고 계층 구조로 구성할 수 있습니다. 작업을 계획하고 우선순위를 지정하고 구성하는데 사용합니다.
<span style="color:red;font-weight:bold">**(작업 그룹화 및 계층화)**</span>

- Sprints: 스프린트 백로그 및 작업 보드는 팀이 특정 반복 경로 또는 스프린트에 할당 한 작업 항목의 필터링 된 보기를 제공합니다. 백로그에서 끌어서 놓기를 사용 하여 반복 경로에 작업을 할당할 수 있습니다. 그런 다음 별도의 스 프린트 백로그에서 해당 작업을 볼 수 있습니다. 이를 사용하여 Scrum 사례를 구현합니다.
<span style="color:red;font-weight:bold">**(Sprint와 scrum 구현)**</span>

- Queries: 쿼리는 쿼리 편집기를 사용 하여 정의하는 조건에 따라 필터링 된 작업 항목 목록입니다. 쿼리를 사용 하여 다음 작업을 지원합니다.
  - 일반적인 항목으로 작업 항목 그룹을 찾습니다.
  - 다른 사람과 공유하거나 대량 업데이트를 수행하기 위해 작업 항목을 나열합니다. 우선순위를 지정하거나 할당할 항목 집합을 심사합니다.
  - 대시보드에 추가할 수 있는 상태 및 추세 차트를 만듭니다.
<span style="color:red;font-weight:bold">**(아직 안써봄)**</span>

# Boards 설명서 링크(Doc)
[Boards 설명서](https://docs.microsoft.com/ko-kr/azure/devops/boards/get-started/what-is-azure-boards?view=azure-devops&tabs=agile-process)


